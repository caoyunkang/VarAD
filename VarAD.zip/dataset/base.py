import json
import os
import random
import numpy as np
import torch.utils.data as data
from PIL import Image
import cv2
import glob
from config import DATA_ROOT
import torch
from PIL import Image

class BaseSolver(object):

    def __init__(self, root, clsnames):
        self.root = root
        self.CLSNAMES = clsnames
        self.path = f'{root}/meta.json'

    def run(self):
        with open(self.path, 'r') as f:
            info = json.load(f)

        info_required = dict(train={}, test={})
        for cls in self.CLSNAMES:
            for k in info.keys():
                info_required[k][cls] = info[k][cls]

        return info_required


class BaseDataset(data.Dataset):
    def __init__(self, class_names, transform, target_transform,
                 root, training):

        self.root = root
        self.transform = transform
        self.target_transform = target_transform
        self.data_all = []

        self.solver = BaseSolver(root, class_names)
        meta_info = self.solver.run()
        self.training = training

        meta_info = meta_info['train'] if training else meta_info['test']

        self.meta_info = meta_info
        self.class_names = class_names

        for cls_name in self.class_names:
            self.data_all.extend(meta_info[cls_name])

        self.count_number(self.data_all)
        self.length = len(self.data_all)

    def count_number(self, data):
        normal_number = 0
        abnormal_number = 0
        for _data in data:
            img_path, mask_path, cls_name, specie_name, anomaly = _data['img_path'], _data['mask_path'], _data['cls_name'], \
                                                                  _data['specie_name'], _data['anomaly']

            if anomaly == 0:
                normal_number += 1
            else:
                abnormal_number += 1

        print(f'Training: {self.training}, Normal: {normal_number}, Abnormal: {abnormal_number}')

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        data = self.data_all[index]
        img_path, mask_path, cls_name, specie_name, anomaly = data['img_path'], data['mask_path'], data['cls_name'], \
                                                              data['specie_name'], data['anomaly']
        img = Image.open(os.path.join(self.root, img_path)).convert('RGB')
        if anomaly == 0:
            img_mask = Image.fromarray(np.zeros((img.size[0], img.size[1])), mode='L')
        else:
            img_mask = np.array(Image.open(os.path.join(self.root, mask_path)).convert('L')) > 0
            img_mask = Image.fromarray(img_mask.astype(np.uint8) * 255, mode='L')

        return_dict = {
            'specie_name': specie_name,
            'cls_name': cls_name,
            'anomaly': anomaly,
            'img_path': os.path.join(self.root, img_path)
        }



        img = self.transform(img) if self.transform is not None else img
        img_mask = self.target_transform(
            img_mask) if self.target_transform is not None and img_mask is not None else img_mask
        img_mask = [] if img_mask is None else img_mask

        return_dict.update({
            'img': img,
            'img_mask': img_mask
        })

        return return_dict
