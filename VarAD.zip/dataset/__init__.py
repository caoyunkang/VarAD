from .base import BaseDataset
from .mvtec import MVTEC_CLS_NAMES, MVTecDataset, MVTEC_ROOT
from .visa import VISA_CLS_NAMES, VisaDataset, VISA_ROOT
from .btad import BTAD_CLS_NAMES, BTADDataset, BTAD_ROOT
from .dtd import DTD_CLS_NAMES,DTDDataset,DTD_ROOT
from torch.utils.data import ConcatDataset

dataset_dict = {
    'btad': (BTAD_CLS_NAMES, BTADDataset, BTAD_ROOT),
    'dtd': (DTD_CLS_NAMES, DTDDataset, DTD_ROOT),
    'mvtec': (MVTEC_CLS_NAMES, MVTecDataset, MVTEC_ROOT),
    'visa': (VISA_CLS_NAMES, VisaDataset, VISA_ROOT),
}

def get_dataset(dataset_types, transform, target_transform, training, class_name_list=None):
    if not isinstance(dataset_types, list):
        dataset_types = [dataset_types]

    dataset_class_names_list = []
    dataset_instances_list = []
    dataset_roots_list = []

    for indx, dataset_type in enumerate(dataset_types):
        if dataset_dict.get(dataset_type, ''):
            dataset_class_names, dataset_instance, dataset_root = dataset_dict[dataset_type]
            if class_name_list is not None:
                dataset_class_names = class_name_list[indx]

            print(dataset_class_names)

            dataset_instance = dataset_instance(
                class_names=dataset_class_names,
                transform=transform,
                target_transform=target_transform,
                training=training
            )

            dataset_class_names_list.append(dataset_class_names)
            dataset_instances_list.append(dataset_instance)
            dataset_roots_list.append(dataset_root)

        else:
            print(f'Only support {dataset_dict.keys()}, but entered {dataset_type}...')
            raise NotImplementedError

    if len(dataset_types) > 1:
        dataset_instance = ConcatDataset(dataset_instances_list)
        dataset_class_names = dataset_class_names_list
        dataset_root = dataset_roots_list
    else:
        dataset_instance = dataset_instances_list[0]
        dataset_class_names = dataset_class_names_list[0]
        dataset_root = dataset_roots_list[0]

    return dataset_class_names, dataset_instance, dataset_root
