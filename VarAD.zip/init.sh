conda create -n varad_env python=3.9.5 -y
conda activate varad_env
conda install pytorch==2.0.1 torchvision==0.15.2 torchaudio==2.0.2 pytorch-cuda=11.8 -c pytorch -c nvidia
pip install numpy==1.25 thop tqdm tensorboard setuptools opencv-python scikit-image scikit-learn matplotlib seaborn ftfy regex Cython


# to install VMamba, we need nvcc > 11.8
# for nvcc -V 11.8
conda install -c nvidia/label/cuda-11.8.0 cuda-nvcc
#wget https://developer.download.nvidia.com/compute/cuda/11.8.0/local_installers/cuda_11.8.0_520.61.05_linux.run
#chmod +x cuda_11.8.0_520.61.05_linux.run
# and pay attention to the paths in this step. option/paths for only the paths that you have admission
# please enter /home/user/cuda-11.8 by default
#sudo sh cuda_11.8.0_520.61.05_linux.run

## Change /home/user to your user dir
export CUDA_HOME=$CUDA_HOME:/home/user/cuda-11.8
export PATH=$PATH:/home/user/cuda-11.8/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/user/cuda-11.8/lib64

### Install VMamba
cd VMamba
pip install -r requirements.txt
cd kernels/selective_scan && pip install .

### for dataset: remember to change the config/global config for the root dir!
